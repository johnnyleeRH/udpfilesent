#include <arpa/inet.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>

#include "protocol.h"
#include "crc.h"

int main() {
    int fd = 0;
    char buf[4096];
    int sockbufsize = 65535;
    int defaultlen = 1468;
    int rawdatalen = 0;
    struct sockaddr_in srcaddr;
    socklen_t addrlen = sizeof(srcaddr);
    ssize_t bytes;
    struct proto *header = NULL;
    unsigned int crc = 0;
    unsigned int rawcrc = 0;
    unsigned int iTable[256];
    memset(iTable, 0, sizeof(iTable));

    if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        printf("create multicast socket failed error %d.", errno);
        return -1;
    }

    setsockopt(fd, SOL_SOCKET, SO_RCVBUF, (char*) &sockbufsize, sizeof(sockbufsize));
    int reuse = 1;
    if (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, (char*) &reuse,
                   sizeof(reuse)) < 0) {
        printf("set udp reuseable failed %d.", errno);
        return -1;
    }

    memset(&srcaddr, 0, sizeof(srcaddr));
    srcaddr.sin_family = AF_INET;
    srcaddr.sin_addr.s_addr = INADDR_ANY;
    srcaddr.sin_port = htons(33001);

    if (bind(fd, (struct sockaddr *)&srcaddr, sizeof(srcaddr)) < 0) {
        printf("bind failed %d.", errno);
        return -1;
    }

    struct ip_mreq mreq;
    mreq.imr_multiaddr.s_addr = inet_addr("233.0.1.1");
    mreq.imr_interface.s_addr = INADDR_ANY;
    if (setsockopt(fd, IPPROTO_IP, IP_ADD_MEMBERSHIP, &mreq, sizeof(mreq)) < 0) {
        printf("set memship failed %d.", errno);
        return -1;
    }

    InitializeCrc(iTable);

    while (1) {
        bytes = recvfrom(fd, buf, 4096, 0,
                         (struct sockaddr *)&srcaddr, &addrlen);
        if (-1 == bytes)
            printf("recv error %d happened.\n", errno);
        else {
            printf("recv %lu msg, header len %lu.\n", bytes, PACKET_HEADER_LEN);
            if (bytes != PACKET_HEADER_LEN + defaultlen + CRC_SIZE)
                printf("error: recv buf bytes wrong.\n");
            header = (struct proto*)buf;
            header->fileno = ntohs(header->fileno);
            header->len = ntohs(header->len);
            if (header->len == 0) {
                rawdatalen = defaultlen;
            } else
                rawdatalen = header->len;
            header->packetno = ntohl(header->packetno);
            crc = CalculateCRC((unsigned char*)buf, PACKET_HEADER_LEN + rawdatalen, iTable);
            rawcrc = *((unsigned int *)(buf + PACKET_HEADER_LEN + defaultlen));
            if (crc != ntohl(rawcrc)) {
                printf("error: crc check %u raw %u.\n", crc, ntohl(rawcrc));
            }
        }
    }
    return 0;
}
