#ifndef UDPFILESENT_MULTICASTSVR_H
#define UDPFILESENT_MULTICASTSVR_H

#include <arpa/inet.h>
/*
 * initial multicast svr for udp sent
 * @addr: input, multicast ip
 * @port: input, multicast port
 * @ttl:  input, multicast ttl len
 * @destaddr: output, dest addr info
 * @return: -1 failed, else udp file descriptor.
 * */
int InitialMulticastSvr(const char* addr, const unsigned short port, const unsigned char ttl, struct sockaddr_in *destaddr);

/*
 * send multicast udp msg
 * @msg: input, udp msg
 * @len: input, msg len
 * @fd: input, udp file id
 * @destaddr: input, dest addr info
 * */
ssize_t SendMsg(const char *msg, const int len, int fd, struct sockaddr_in *destaddr);

/*
 * destory the udp resource
 * @fd: input, udp file descriptor
 * */
void CloseMulticastSvr(int fd);

#endif
