#ifndef UDPFILESENT_PARAMDEF_H
#define UDPFILESENT_PARAMDEF_H

#include <stdint.h>

#define MAX_PARAM        21
#define TIME_FORMAT_LEN  19
#define MAX_IP_LEN       15
#define MPSIZE_LIMIT     4096
#define MULTNUM_LIMIT    255
#define SFILES_LIMIT     65525
#define AFILES_LIMIT     255
#define ATIMES_LIMIT     32
#define MBANDWIDTH_LIMIT 1000000000

struct inputparam {
    uint8_t multnum;
    uint8_t afiles;
    uint8_t atimes;
    uint8_t pausecmd;
    uint16_t mpsize;
    uint16_t sfiles;
    uint16_t multport;
    uint64_t mbandwidth;
    uint8_t starttime[20];
    uint8_t endtime[20];
    uint8_t multip[16];
    uint8_t smpath[1024];
};

struct calcparam {
    uint64_t sfilesize;
    uint64_t stotalpackets;
    uint64_t filesize;
    uint64_t fileptotal;
    uint8_t  current[20];
};

struct outputparam {
    uint8_t  curmultround;
    uint16_t filenum;
    uint64_t smpnum;
    uint64_t rbandwidth;
    uint64_t mduringtime;
    uint8_t  roundbegin[20];
};

#endif
