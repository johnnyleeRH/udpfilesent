#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <unistd.h>

#include "log.h"
#include "multicastsvr.h"

int InitialMulticastSvr(const char* addr, const unsigned short port, const unsigned char ttl, struct sockaddr_in *destaddr) {
    uint8_t ipttl = ttl;
    int udpfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (-1 == udpfd) {
        ERROR("create multicast socket failed error %d.", errno);
        return -1;
    }
    if (-1 == setsockopt(udpfd, IPPROTO_IP, IP_MULTICAST_TTL, &ipttl, sizeof(ipttl))) {
        ERROR("set ttl failed %d.", errno);
    }
    INFO("multicast addr %s, port %u.", addr, port);
    memset(destaddr, 0, sizeof(struct sockaddr_in));
    destaddr->sin_family = AF_INET;
    destaddr->sin_addr.s_addr = inet_addr(addr);
    destaddr->sin_port = htons(port);
    return udpfd;
}

ssize_t SendMsg(const char *msg, const int len, int fd, struct sockaddr_in *destaddr) {
    ssize_t sentsize = sendto(fd, msg, len, 0, (struct sockaddr *)destaddr, sizeof(struct sockaddr_in));
    if (-1 == sentsize)
        ERROR("send msg failed %d.", errno);
    else if (sentsize != len)
        INFO("sent size %d not equal to need size %d.", sentsize, len);
    return sentsize;
}

void CloseMulticastSvr(int fd) {
    close(fd);
}