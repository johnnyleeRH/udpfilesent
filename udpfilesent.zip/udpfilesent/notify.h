#ifndef UDPFILESENT_NOTIFY_H
#define UDPFILESENT_NOTIFY_H

/*
 * notify app to stop.
 * */
void NotifyStopApplication();

/*
 * check whether app shall stop or not.
 * @return: 0, no need stop, else need stop.
 * */
int IsAppToBeStopped();

#endif
