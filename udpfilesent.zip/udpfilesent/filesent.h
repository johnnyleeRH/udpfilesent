#ifndef UDPFILESENT_FILESENT_H
#define UDPFILESENT_FILESENT_H

#define ROUND(f) (f >= 0 ? (long)(f + 0.5) : (long)(f - 0.5))

#ifndef TIMEVAL_TO_TIMESPEC
#define TIMEVAL_TO_TIMESPEC(tv, ts) {       \
    (ts)->tv_sec = (tv)->tv_sec;            \
    (ts)->tv_nsec = (tv)->tv_usec * 1000;   \
}
#endif

/*
 * get the usec sleep time by current packet len and bandwidth
 * @pktlen: input, current packet len, byte unit
 * @linerate: input, bandwith limit, bit unit
 * @return usec
 * */
int LinerateInterval(const int pktlen, const int linerate);

void SendFilePackets();

/*
 * loop timer handle.
 * */
void TimerHandle(sigval_t);
/*
 * @paused: input, 0 not paused, else file sent paused.
 * */
void SetPauseState(int paused);
#endif
