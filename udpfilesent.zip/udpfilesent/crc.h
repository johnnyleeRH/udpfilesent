#ifndef UDPFILESENT_CRC_H
#define UDPFILESENT_CRC_H

/*
 * @iTable: input, shall be an unsigned int array of 256 length.
 * */
void InitializeCrc(unsigned int *iTable);
/*
 * @iTable: input, shall be initialed by InitializeCrc first.
 * Returns the calculated CRC32 for the given string.
*/
unsigned int CalculateCRC(const unsigned char *sData, size_t iDataLength, const unsigned int *iTable);

#endif
