#ifndef UDPFILESENT_TIMEOPR_H
#define UDPFILESENT_TIMEOPR_H

#include <stdlib.h>
/*
 * delte timer
 * @timerid: input, timer id.
 * */
void DeleteLoopTimer(timer_t timerid);

/*
 * set loop timer
 * @func: input, func to handle when timer expire
 * @return: timerid success, NULL failed
 * */
timer_t SetLoopTimer(void* func, void* param);

/*
 * @tm: output, get the formatted time, tm shall be more than 20 bytes
 * */
void GetCurrentTime(char* tm);

/*
 * @tm: input, the formatted time buf
 * @return the seconds from the formatted time
 * */
time_t GetSecondsFromTime(const char* tm);

/*
 * @begin: input, the formatted begin time
 * @end: input, the formatted end time
 * @return the diff seconds of the begin and end time
 * */
time_t GetTimeDif(const char* begin, const char* end);

#endif
