#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "log.h"
#include "paramdef.h"
#include "timeopr.h"
#include "protocol.h"

struct inputparam  input;
struct outputparam output;
struct calcparam   calculate;
static char filebuf[MAX_PARAM][1024];
static ssize_t linelen[MAX_PARAM];
static char inifile[1024] = "0";
FILE *inistream;
char *line = NULL;

int InitConfigure(char *file) {
    int index = 0;
    memcpy(inifile, file, sizeof(inifile));
    inistream = fopen(file, "r+");
    if (inistream == NULL) {
        ERROR("file %s open failed.", file);
        return -1;
    }
    line = malloc(1024);
    if (NULL == line) {
        ERROR("fail to malloc for file line.");
        fclose(inistream);
        return -1;
    }
    memset(&input, 0, sizeof(input));
    memset(&output, 0, sizeof(output));
    memset(&calculate, 0, sizeof(calculate));
    for (index = 0; index < MAX_PARAM; index++)
        memset(filebuf[index], 0, 1024);
    return 0;
}

void FinConfigure() {
    free(line);
    fclose(inistream);
}

void logInput() {
    INFO("mbandwidth %lu\n", input.mbandwidth);
    INFO("multport   %u\n",  input.multport);
    INFO("afiles     %u\n",  input.afiles);
    INFO("atimes     %u\n",  input.atimes);
    INFO("mpsize     %u\n",  input.mpsize);
    INFO("multnum    %u\n",  input.multnum);
    INFO("pausecmd   %u\n",  input.pausecmd);
    INFO("sfiles     %u\n",  input.sfiles);
    INFO("starttime  %s\n",  input.starttime);
    INFO("endtime    %s\n",  input.endtime);
    INFO("multip     %s\n",  input.multip);
    INFO("smpath     %s\n",  input.smpath);
}

int checkInput() {
    if ((0 == input.mpsize)
            || (0 == input.multnum)
            || (0 == input.sfiles)
            || (0 == input.mbandwidth)) {
        ERROR("%d %d %d %lu.\n", input.mpsize, input.multnum, input.sfiles, input.mbandwidth);
        return -1;
    }
    if (GetTimeDif((char*)input.starttime, (char*)input.endtime) <= 0){
        ERROR("start %s.\n", input.starttime);
        ERROR("end %s.\n", input.endtime);
        return -1;
    }

    return 0;
}

int GetInputParam() {
    size_t len = 1024;
    ssize_t nread;
    int value = 0;
    long bandwidth = 0;
    int fileline = 0;
    fseek(inistream, 0, SEEK_SET);

    while ((nread = getline(&line, &len, inistream)) != -1) {
        if (0 == strncmp(line, "mpsize", strlen("mpsize"))) {
            value = atoi(line + strlen("mpsize") + 1);
            if ((unsigned)value > MPSIZE_LIMIT) {
                ERROR("mpsize: %s", line);
                return -1;
            }
            input.mpsize = value;
        } else if (0 == strncmp(line, "multnum", strlen("multnum"))) {
            value = atoi(line + strlen("multnum") + 1);
            if ((unsigned)value + CRC_SIZE + sizeof(struct proto) > MULTNUM_LIMIT) {
                ERROR("multnum: %s", line);
                return -1;
            }
            input.multnum = value;
        } else if (0 == strncmp(line, "sfiles=", strlen("sfiles="))) {
            value = atoi(line + strlen("sfiles") + 1);
            if ((unsigned)value > SFILES_LIMIT) {
                ERROR("sfiles: %s", line);
                return -1;
            }
            input.sfiles = value;
        } else if (0 == strncmp(line, "afiles", strlen("afiles"))) {
            value = atoi(line + strlen("afiles") + 1);
            if ((unsigned)value > AFILES_LIMIT) {
                ERROR("afiles: %s", line);
                return -1;
            }
            input.afiles = value;
        } else if (0 == strncmp(line, "atimes", strlen("atimes"))) {
            value = atoi(line + strlen("atimes") + 1);
            if ((unsigned)value > ATIMES_LIMIT) {
                ERROR("atimes: %s", line);
                return -1;
            }
            input.atimes = value;
        } else if (0 == strncmp(line, "pausecmd", strlen("pausecmd"))) {
            if (nread > strlen("pausecmd") + 3) {
                ERROR("pausecmd: %s", line);
                return -1;
            }
            input.pausecmd = atoi(line + strlen("pausecmd") + 1);
        } else if (0 == strncmp(line, "starttime", strlen("starttime"))) {
            if (nread - strlen("starttime") - 2 != TIME_FORMAT_LEN) {
                ERROR("start time %d: %s", nread, line);
                return -1;
            }
            memcpy(input.starttime, line + strlen("starttime") + 1, TIME_FORMAT_LEN);
        } else if (0 == strncmp(line, "endtime", strlen("endtime"))) {
            if (nread - strlen("endtime") - 2 != TIME_FORMAT_LEN) {
                ERROR("end time %d: %s", nread, line);
                return -1;
            }
            memcpy(input.endtime, line + strlen("endtime") + 1, TIME_FORMAT_LEN);
        } else if (0 == strncmp(line, "multip", strlen("multip"))) {
            if (nread - strlen("multip") - 2 > MAX_IP_LEN) {
                ERROR("multi ip %d: %s", nread, line);
                return -1;
            }
            memcpy(input.multip, line + strlen("multip") + 1, nread - strlen("multip") - 2);
        } else if (0 == strncmp(line, "multport", strlen("multport"))) {
            input.multport = atoi(line + strlen("multport") + 1);
        } else if (0 == strncmp(line, "mbandwidth", strlen("mbandwidth"))) {
            bandwidth = atol(line + strlen("mbandwidth") + 1);
            if ((unsigned)bandwidth > MBANDWIDTH_LIMIT) {
                ERROR("mbandwidth: %s", line);
                return -1;
            }
            input.mbandwidth = bandwidth;
        } else if (0 == strncmp(line, "smpath", strlen("smpath"))) {
            if (nread >= 1024) {
                ERROR("file path %d.");
                return -1;
            }
            memcpy(input.smpath, line + strlen("smpath") + 1, nread - strlen("smpath") - 2);
        }
        if (fileline >= MAX_PARAM) {
            ERROR("fileline %d overflow.", fileline);
            return -1;
        }
        memcpy(filebuf[fileline], line, nread);
        linelen[fileline++] = nread;
    }

    if (checkInput() < 0) {
        ERROR("input check failed.");
        return -1;
    }
    logInput();
    return 0;
}

void fillinter(char* tag, uint16_t val, int lineno) {
    char buf[10];
    int index = 0;

    memset(buf, 0, 10);
    sprintf(buf, "%u", val);
    memcpy((char*)filebuf[lineno] + strlen(tag) + 1, buf, strlen(buf));
    if (strlen(buf) >= linelen[lineno] - strlen(tag) - 2) {
        filebuf[lineno][strlen(tag) + 1 + strlen(buf)] = '\n';
        linelen[lineno] = strlen(filebuf[lineno]);
    } else {
        for (index = strlen(tag) + 1 + strlen(buf); index < linelen[lineno] - 1; ++index)
            filebuf[lineno][index] = 0;
    }
}

void filllong(char* tag, uint64_t val, int lineno) {
    char buf[20];
    int index = 0;

    memset(buf, 0, 20);
    sprintf(buf, "%lu", val);
    memcpy((char*)filebuf[lineno] + strlen(tag) + 1, buf, strlen(buf));
    if (strlen(buf) >= linelen[lineno] - strlen(tag) - 2) {
        filebuf[lineno][strlen(tag) + 1 + strlen(buf)] = '\n';
        linelen[lineno] = strlen(filebuf[lineno]);
    } else {
        for (index = strlen(tag) + 1 + strlen(buf); index < linelen[lineno] - 1; ++index)
            filebuf[lineno][index] = 0;
    }
}

int UpdateParam() {
    size_t len = 1024;
    ssize_t nread;
    int fileline = 0;
    int index = 0;
    size_t writesize = 0;
    inistream = freopen(inifile, "r+", inistream);
    if (inistream == NULL) {
        ERROR("file reopen failed.");
        return -1;
    }
    //fseek(inistream, 0, SEEK_SET);
    /**
     * get the value of the input which can be changed first.
     * */
    while ((nread = getline(&line, &len, inistream)) != -1) {
        if (0 == strncmp(line, "pausecmd", strlen("pausecmd"))) {
            if (nread > strlen("pausecmd") + 3) {
                ERROR("pausecmd: %s", line);
                return -1;
            }
            input.pausecmd = atoi(line + strlen("pausecmd") + 1);
            printf("get paused cmd from file is %d.", input.pausecmd);
            memcpy(filebuf[fileline], line, nread);
        } else if (0 == strncmp(line, "endtime", strlen("endtime"))) {
            if (nread - strlen("endtime") - 2 != TIME_FORMAT_LEN) {
                ERROR("end time %d: %s", nread, line);
                return -1;
            }
            memcpy(input.endtime, line + strlen("endtime") + 1, TIME_FORMAT_LEN);
            memcpy(filebuf[fileline], line, nread);
        }
        fileline++;
    }

    /**
     *update the ini file, the line length just can be expand, can't narrow
     */
    fseek(inistream, 0, SEEK_SET);

    for (index = 0; index < MAX_PARAM; index++) {
        if (0 == strncmp(filebuf[index], "sfilesize", strlen("sfilesize"))) {
            filllong("sfilesize", calculate.sfilesize, index);
        } else if (0 == strncmp(filebuf[index], "stotalpackets", strlen("stotalpackets"))) {
            filllong("stotalpackets", calculate.stotalpackets, index);
        } else if (0 == strncmp(filebuf[index], "filenum", strlen("filenum"))) {
            fillinter("filenum", output.filenum, index);
        } else if (0 == strncmp(filebuf[index], "filesize", strlen("filesize"))) {
            filllong("filesize", calculate.filesize, index);
        } else if (0 == strncmp(filebuf[index], "fileptotal", strlen("fileptotal"))) {
            filllong("fileptotal", calculate.fileptotal, index);
        } else if (0 == strncmp(filebuf[index], "smpnum", strlen("smpnum"))) {
            filllong("smpnum", output.smpnum, index);
        } else if (0 == strncmp(filebuf[index], "currenttime", strlen("currenttime"))) {
            memcpy((char*)filebuf[index] + strlen("currenttime") + 1, calculate.current, strlen((char*)calculate.current));
        } else if (0 == strncmp(filebuf[index], "rbandwidth", strlen("rbandwidth"))) {
            filllong("rbandwidth", output.rbandwidth, index);
        } else if (0 == strncmp(filebuf[index], "mduringtime", strlen("mduringtime"))) {
            filllong("mduringtime", output.mduringtime, index);
        }

        writesize = fwrite(filebuf[index], 1, linelen[index], inistream);

        if (writesize != linelen[index]) {
            ERROR("write[%d] failed errno %d\n.", index, errno);
        }
    }

    fflush(inistream);

    if (checkInput() < 0) {
        ERROR("input check failed.");
        return -1;
    }
    return 0;
}

uint16_t GetCurrentFileNo() {
    return output.filenum;
}

uint64_t GetCurrentPackNo() {
    return output.smpnum;
}

uint64_t GetCurrentBandWidth() {
    return output.rbandwidth;
}

uint64_t GetLastTimeCost() {
    return output.mduringtime;
}

uint8_t GetCurrentMulticastRound() {
    return output.curmultround;
}

void GetRoundBeginTime(char* begin) {
    memcpy(begin, output.roundbegin, sizeof(output.roundbegin));
}