#include <errno.h>
#include <stdlib.h>
#include <string.h>

#include "log.h"
#include "timeopr.h"
#include "protocol.h"
#include "iniopr.h"

FILE* InitConfigure(char *file, char *line) {
    FILE *inistream = NULL;
    inistream = fopen(file, "r+");
    if (inistream == NULL) {
        ERROR("file %s open failed.", file);
        return NULL;
    }
    line = malloc(1024);
    if (NULL == line) {
        ERROR("fail to malloc for file line.");
        fclose(inistream);
        return NULL;
    }
    return inistream;
}

void FinConfigure(char* line, FILE* inistream) {
    free(line);
    fclose(inistream);
}

void logInput(const struct inputparam *input) {
    INFO("mbandwidth %lu\n", input->mbandwidth);
    INFO("multport   %u\n",  input->multport);
    INFO("afiles     %u\n",  input->afiles);
    INFO("atimes     %u\n",  input->atimes);
    INFO("mpsize     %u\n",  input->mpsize);
    INFO("pausecmd   %u\n",  input->pausecmd);
    INFO("sfiles     %u\n",  input->sfiles);
    INFO("starttime  %s\n",  input->starttime);
    INFO("endtime    %s\n",  input->endtime);
    INFO("multip     %s\n",  input->multip);
    INFO("smpath     %s\n",  input->smpath);
    INFO("udpttl     %u\n",  input->udpttl);
}

int checkInput(const struct inputparam *input) {
    if ((0 == input->mpsize)
            || (0 == input->sfiles)
            || (0 == input->mbandwidth)) {
        ERROR("%d %d %lu.\n", input->mpsize, input->sfiles, input->mbandwidth);
        return -1;
    }
    if (GetTimeDif((char*)input->starttime, (char*)input->endtime) <= 0){
        ERROR("start %s.\n", input->starttime);
        ERROR("end %s.\n", input->endtime);
        return -1;
    }

    return 0;
}

int GetInputParam(struct inifileopr* cfgopr) {
    size_t len = 1024;
    ssize_t nread;
    int value = 0;
    long bandwidth = 0;
    int fileline = 0;
    fseek(cfgopr->inistream, 0, SEEK_SET);

    while ((nread = getline(&cfgopr->line, &len, cfgopr->inistream)) != -1) {
        if (0 == strncmp(cfgopr->line, "mpsize", strlen("mpsize"))) {
            value = atoi(cfgopr->line + strlen("mpsize") + 1);
            if ((unsigned)value > MPSIZE_LIMIT) {
                ERROR("mpsize: %s", cfgopr->line);
                return -1;
            }
            cfgopr->input.mpsize = value;
        } else if (0 == strncmp(cfgopr->line, "udpttl", strlen("udpttl"))) {
            value = atoi(cfgopr->line + strlen("udpttl") + 1);
            if ((unsigned)value > TTL_LIMIT) {
                ERROR("udpttl: %s", cfgopr->line);
                return -1;
            }
            cfgopr->input.udpttl = value;
        } else if (0 == strncmp(cfgopr->line, "sfiles=", strlen("sfiles="))) {
            value = atoi(cfgopr->line + strlen("sfiles") + 1);
            if ((unsigned)value > SFILES_LIMIT) {
                ERROR("sfiles: %s", cfgopr->line);
                return -1;
            }
            cfgopr->input.sfiles = value;
        } else if (0 == strncmp(cfgopr->line, "afiles", strlen("afiles"))) {
            value = atoi(cfgopr->line + strlen("afiles") + 1);
            if ((unsigned)value > AFILES_LIMIT) {
                ERROR("afiles: %s", cfgopr->line);
                return -1;
            }
            cfgopr->input.afiles = value;
        } else if (0 == strncmp(cfgopr->line, "atimes", strlen("atimes"))) {
            value = atoi(cfgopr->line + strlen("atimes") + 1);
            if ((unsigned)value > ATIMES_LIMIT) {
                ERROR("atimes: %s", cfgopr->line);
                return -1;
            }
            cfgopr->input.atimes = value;
        } else if (0 == strncmp(cfgopr->line, "pausecmd", strlen("pausecmd"))) {
            if (nread > strlen("pausecmd") + 3) {
                ERROR("pausecmd: %s", cfgopr->line);
                return -1;
            }
            cfgopr->input.pausecmd = atoi(cfgopr->line + strlen("pausecmd") + 1);
        } else if (0 == strncmp(cfgopr->line, "starttime", strlen("starttime"))) {
            if (nread - strlen("starttime") - 2 != TIME_FORMAT_LEN) {
                ERROR("start time %d: %s", nread, cfgopr->line);
                return -1;
            }
            memcpy(cfgopr->input.starttime, cfgopr->line + strlen("starttime") + 1, TIME_FORMAT_LEN);
        } else if (0 == strncmp(cfgopr->line, "endtime", strlen("endtime"))) {
            if (nread - strlen("endtime") - 2 != TIME_FORMAT_LEN) {
                ERROR("end time %d: %s", nread, cfgopr->line);
                return -1;
            }
            memcpy(cfgopr->input.endtime, cfgopr->line + strlen("endtime") + 1, TIME_FORMAT_LEN);
        } else if (0 == strncmp(cfgopr->line, "multip", strlen("multip"))) {
            if (nread - strlen("multip") - 2 > MAX_IP_LEN) {
                ERROR("multi ip %d: %s", nread, cfgopr->line);
                return -1;
            }
            memcpy(cfgopr->input.multip, cfgopr->line + strlen("multip") + 1, nread - strlen("multip") - 2);
        } else if (0 == strncmp(cfgopr->line, "multport", strlen("multport"))) {
            cfgopr->input.multport = atoi(cfgopr->line + strlen("multport") + 1);
        } else if (0 == strncmp(cfgopr->line, "mbandwidth", strlen("mbandwidth"))) {
            bandwidth = atol(cfgopr->line + strlen("mbandwidth") + 1);
            if ((unsigned)bandwidth > MBANDWIDTH_LIMIT) {
                ERROR("mbandwidth: %s", cfgopr->line);
                return -1;
            }
            cfgopr->input.mbandwidth = bandwidth;
        } else if (0 == strncmp(cfgopr->line, "smpath", strlen("smpath"))) {
            if (nread >= 1024) {
                ERROR("file path %d.");
                return -1;
            }
            memcpy(cfgopr->input.smpath, cfgopr->line + strlen("smpath") + 1, nread - strlen("smpath") - 2);
        }
        if (fileline >= MAX_PARAM) {
            ERROR("fileline %d overflow.", fileline);
            return -1;
        }
        memcpy(cfgopr->filebuf[fileline], cfgopr->line, nread);
        cfgopr->linelen[fileline++] = nread;
    }

    if (checkInput(&cfgopr->input) < 0) {
        ERROR("input check failed.");
        return -1;
    }
    logInput(&cfgopr->input);
    return 0;
}

void fillinter(char* tag, uint16_t val, int lineno, char** filebuf, ssize_t* linelen) {
    char buf[10];
    int index = 0;

    memset(buf, 0, 10);
    sprintf(buf, "%u", val);
    memcpy((char*)filebuf[lineno] + strlen(tag) + 1, buf, strlen(buf));
    if (strlen(buf) >= linelen[lineno] - strlen(tag) - 2) {
        filebuf[lineno][strlen(tag) + 1 + strlen(buf)] = '\n';
        linelen[lineno] = strlen(filebuf[lineno]);
    } else {
        for (index = strlen(tag) + 1 + strlen(buf); index < linelen[lineno] - 1; ++index)
            filebuf[lineno][index] = 0;
    }
}

void filllong(char* tag, uint64_t val, int lineno, char** filebuf, ssize_t* linelen) {
    char buf[20];
    int index = 0;

    memset(buf, 0, 20);
    sprintf(buf, "%lu", val);
    memcpy((char*)filebuf[lineno] + strlen(tag) + 1, buf, strlen(buf));
    if (strlen(buf) >= linelen[lineno] - strlen(tag) - 2) {
        filebuf[lineno][strlen(tag) + 1 + strlen(buf)] = '\n';
        linelen[lineno] = strlen(filebuf[lineno]);
    } else {
        for (index = strlen(tag) + 1 + strlen(buf); index < linelen[lineno] - 1; ++index)
            filebuf[lineno][index] = 0;
    }
}

int UpdateParam(struct inifileopr* cfgopr) {
    size_t len = 1024;
    ssize_t nread;
    int fileline = 0;
    int index = 0;
    size_t writesize = 0;
    cfgopr->inistream = freopen(cfgopr->inipath, "r+", cfgopr->inistream);
    if (cfgopr->inistream == NULL) {
        ERROR("file reopen failed.");
        return -1;
    }
    /**
     * get the value of the input which can be changed first.
     * */
    while ((nread = getline(&cfgopr->line, &len, cfgopr->inistream)) != -1) {
        if (0 == strncmp(cfgopr->line, "pausecmd", strlen("pausecmd"))) {
            if (nread > strlen("pausecmd") + 3) {
                ERROR("pausecmd: %s", cfgopr->line);
                return -1;
            }
            cfgopr->input.pausecmd = atoi(cfgopr->line + strlen("pausecmd") + 1);
            memcpy(cfgopr->filebuf[fileline], cfgopr->line, nread);
        } else if (0 == strncmp(cfgopr->line, "endtime", strlen("endtime"))) {
            if (nread - strlen("endtime") - 2 != TIME_FORMAT_LEN) {
                ERROR("end time %d: %s", nread, cfgopr->line);
                return -1;
            }
            memcpy(cfgopr->input.endtime, cfgopr->line + strlen("endtime") + 1, TIME_FORMAT_LEN);
            memcpy(cfgopr->filebuf[fileline], cfgopr->line, nread);
        }
        fileline++;
    }

    /**
     *update the ini file, the line length just can be expand, can't narrow
     */
    fseek(cfgopr->inistream, 0, SEEK_SET);

    for (index = 0; index < MAX_PARAM; index++) {
        if (0 == strncmp(cfgopr->filebuf[index], "sfilesize", strlen("sfilesize"))) {
            filllong("sfilesize", cfgopr->calculate.sfilesize, index, cfgopr->filebuf, cfgopr->linelen);
        } else if (0 == strncmp(cfgopr->filebuf[index], "stotalpackets", strlen("stotalpackets"))) {
            filllong("stotalpackets", cfgopr->calculate.stotalpackets, index, cfgopr->filebuf, cfgopr->linelen);
        } else if (0 == strncmp(cfgopr->filebuf[index], "filenum", strlen("filenum"))) {
            fillinter("filenum", cfgopr->output.filenum, index, cfgopr->filebuf, cfgopr->linelen);
        } else if (0 == strncmp(cfgopr->filebuf[index], "filesize", strlen("filesize"))) {
            filllong("filesize", cfgopr->calculate.filesize, index, cfgopr->filebuf, cfgopr->linelen);
        } else if (0 == strncmp(cfgopr->filebuf[index], "fileptotal", strlen("fileptotal"))) {
            filllong("fileptotal", cfgopr->calculate.fileptotal, index, cfgopr->filebuf, cfgopr->linelen);
        } else if (0 == strncmp(cfgopr->filebuf[index], "smpnum", strlen("smpnum"))) {
            filllong("smpnum", cfgopr->output.smpnum, index, cfgopr->filebuf, cfgopr->linelen);
        } else if (0 == strncmp(cfgopr->filebuf[index], "currenttime", strlen("currenttime"))) {
            memcpy(cfgopr->filebuf[index] + strlen("currenttime") + 1, cfgopr->calculate.current, strlen((char*)cfgopr->calculate.current));
        } else if (0 == strncmp(cfgopr->filebuf[index], "rbandwidth", strlen("rbandwidth"))) {
            filllong("rbandwidth", cfgopr->output.rbandwidth, index, cfgopr->filebuf, cfgopr->linelen);
        } else if (0 == strncmp(cfgopr->filebuf[index], "mduringtime", strlen("mduringtime"))) {
            filllong("mduringtime", cfgopr->output.mduringtime, index, cfgopr->filebuf, cfgopr->linelen);
        } else if (0 == strncmp(cfgopr->filebuf[index], "multnum", strlen("multnum"))) {
            fillinter("multnum", cfgopr->output.curmultround, index, cfgopr->filebuf, cfgopr->linelen);
        }

        writesize = fwrite(cfgopr->filebuf[index], 1, cfgopr->linelen[index], cfgopr->inistream);

        if (writesize != cfgopr->linelen[index]) {
            ERROR("write[%d] failed errno %d\n.", index, errno);
        }
    }

    fflush(cfgopr->inistream);

    if (checkInput(&cfgopr->input) < 0) {
        ERROR("input check failed.");
        return -1;
    }
    return 0;
}
#if 0
uint16_t GetCurrentFileNo() {
    return output.filenum;
}

uint64_t GetCurrentPackNo() {
    return output.smpnum;
}

uint64_t GetCurrentBandWidth() {
    return output.rbandwidth;
}

uint64_t GetLastTimeCost() {
    return output.mduringtime;
}

uint8_t GetCurrentMulticastRound() {
    return output.curmultround;
}

void GetRoundBeginTime(char* begin) {
    memcpy(begin, output.roundbegin, sizeof(output.roundbegin));
}

uint64_t GetLimitBandWidth() {
    return input.mbandwidth;
}

uint16_t GetMulticastPort() {
    return input.multport;
}

uint8_t GetPriorityFiles() {
    return input.afiles;
}

uint8_t GetPriorityCounts() {
    return input.atimes;
}

uint16_t GetPacketLen() {
    return input.mpsize;
}

uint8_t GetPausedCmd() {
    return input.pausecmd;
}

uint16_t GetTotalFiles() {
    return input.sfiles;
}

void GetStartTime(char* start) {
    memcpy(start, input.starttime, sizeof(input.starttime));
}

void GetEndTime(char* end) {
    memcpy(end, input.endtime, sizeof(input.endtime));
}

void GetMulticastIp(char* ip) {
    memcpy(ip, (char*)input.multip, sizeof(input.multip));
}

void GetFileFolder(char* folder) {
    memcpy(folder, (char*)input.smpath, sizeof(input.smpath));
}

uint8_t GetUdpTtl() {
    return input.udpttl;
}

void SetCurrentMulticastRound(uint8_t round) {
    output.curmultround = round;
}

void SetCurrentFileNo(uint16_t fileno) {
    output.filenum = fileno;
}

void SetCurrentPackNo(uint64_t packetno) {
    output.smpnum = packetno;
}

void SetCurrentBandWidth(uint64_t bandwidth) {
    output.rbandwidth = bandwidth;
}

void SetDuringTime(uint64_t sec) {
    output.mduringtime = sec;
}

void SetRoundBeginTime(char* tm) {
    memcpy((char*)output.roundbegin, tm, sizeof(output.roundbegin));
}
#endif