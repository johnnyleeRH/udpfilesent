#include <arpa/inet.h>
#include <errno.h>
#include <signal.h>
#include <sys/time.h>
#include <time.h>
#include <stdio.h>
#include <string.h>

#include "crc.h"
#include "filesent.h"
#include "iniopr.h"
#include "protocol.h"
#include "log.h"
#include "multicastsvr.h"
#include "timeopr.h"
#include "notify.h"

/*
 * Calculate line rate interval in microseconds for the given
 * pkt_len (bytes) and linerate (bit)
 *
 * to send packets at line rate with assumption of link speed at X:
 * interval = ((packet length * bits per byte) / (X)) * 1000000
 * ex:
 * +---------------------------------------------------+
 * |            | 10Mbps      | 100Mbps    | 1000Mbps  |
 * +---------------------------------------------------+
 * |   14 bytes | 11 usecs.   | 1 usecs.   | 0 usecs.  |
 * | 1514 bytes | 1155 usecs. | 116 usecs. | 12 usecs. |
 * +---------------------------------------------------+
 */

int LinerateInterval(const int pktlen, const int linerate) {
    return ROUND(((float)pktlen * 8) / linerate * 1000000);
}

void TimerHandle(sigval_t sigval) {
    struct inifileopr *cfgopr = (struct inifileopr *)sigval.sival_ptr;
    GetCurrentTime((char*)cfgopr->calculate.current);
    cfgopr->output.rbandwidth = cfgopr->output.curbandwidth * 8;
    UpdateParam(cfgopr);
    if (GetTimeDif((char*)cfgopr->calculate.current, (char*)cfgopr->input.endtime) < 0) {
        INFO("endtime is early than current.");
        NotifyStopApplication();
        return;
    }
    cfgopr->output.curbandwidth = 0;
}

void preparefile(struct inifileopr *cfgopr, FILE** stream) {
    static char fileid[1024];
    static int curatime = 1;
    const uint8_t afiles = cfgopr->input.afiles;
    const uint16_t sfiles = cfgopr->input.sfiles;
    const uint16_t packetlen = cfgopr->input.mpsize;
    const uint8_t atimes = cfgopr->input.atimes;
    const int originfile = cfgopr->output.filenum;
    int errtag = 0;
    char roundend[20] = "0";

    if (*stream != NULL)
        return;
    while (cfgopr->output.curmultround <= MULTNUM_LIMIT) {
        /*
         * just exception handing
         * */
        if (afiles >= sfiles) {
            if (cfgopr->output.filenum < sfiles) {
                cfgopr->output.filenum++;
            } else {
                if (atimes == 0 || atimes == 1) {
                    if (cfgopr->output.filenum == sfiles) {
                        cfgopr->output.filenum = 1;
                        if (cfgopr->output.curmultround == MULTNUM_LIMIT) {
                            ERROR("multicast times over %d.", MULTNUM_LIMIT);
                            return;
                        }
                        cfgopr->output.curmultround++;
                    }
                } else {
                    if (cfgopr->output.filenum == sfiles) {
                        cfgopr->output.filenum = 1;
                        if (curatime == atimes) {
                            curatime = 1;
                            if (cfgopr->output.curmultround == MULTNUM_LIMIT) {
                                ERROR("multicast times over %d.", MULTNUM_LIMIT);
                                return;
                            }
                            cfgopr->output.curmultround++;
                        } else {
                            curatime++;
                        }
                    }
                }
            }
        } else {
            if (cfgopr->output.filenum < afiles) {
                cfgopr->output.filenum++;
            } else if (cfgopr->output.filenum == afiles) {
                if (0 == atimes || 1 == atimes) {
                    cfgopr->output.filenum++;
                } else {
                    if (curatime < atimes) {
                        curatime++;
                        cfgopr->output.filenum = 1;
                    } else {
                        curatime = 1;
                        cfgopr->output.filenum++;
                    }
                }
            } else {
                if (cfgopr->output.filenum < sfiles) {
                    cfgopr->output.filenum++;
                } else {
                    cfgopr->output.filenum = 1;
                    if (cfgopr->output.curmultround == MULTNUM_LIMIT) {
                        ERROR("multicast times over %d.", MULTNUM_LIMIT);
                        return;
                    }
                    cfgopr->output.curmultround++;
                }
            }
        }
        memset(fileid, 0, sizeof(fileid));
        snprintf(fileid, sizeof(fileid), "%s%d", cfgopr->input.smpath, cfgopr->output.filenum);

        if (cfgopr->output.filenum == 1) {
            GetCurrentTime((char *)cfgopr->output.roundbegin);
        }
        *stream = fopen(fileid, "r");
        if (*stream == NULL) {
            errtag = errno;
            if (2 != errtag)
                ERROR("file %s open failed %d.", fileid, errtag);
            if (cfgopr->output.filenum == sfiles) {
                GetCurrentTime(roundend);
                cfgopr->output.mduringtime = GetTimeDif((char*)cfgopr->output.roundbegin, roundend);
            }
            /*means that circle search but no file can be opened, shall stop multicast.*/
            if (originfile == cfgopr->output.filenum) {
                INFO("no file need to send.");
                NotifyStopApplication();
                return;
            }
            continue;
        }
        fseek(*stream, 0, SEEK_END);
        cfgopr->calculate.filesize = ftell(*stream);
        cfgopr->calculate.fileptotal = (cfgopr->calculate.filesize + packetlen - 1) / packetlen;
        rewind(*stream);
        cfgopr->output.smpnum = 0;
        return;
    }
}

int readfile(struct inifileopr *cfgopr, char* msgbuf) {
    size_t readsize = 0;
    static FILE* stream = NULL;
    const uint16_t packetlen = cfgopr->input.mpsize;
    const uint16_t totalfiles = cfgopr->input.sfiles;
    int errtag = 0;
    char roundend[20] = "0";
    preparefile(cfgopr, &stream);
    if (stream != NULL) {
        readsize = fread(msgbuf + PACKET_HEADER_LEN, 1, packetlen, stream);
        cfgopr->output.smpnum++;
        if (readsize != packetlen) {
            errtag = errno;
            if (errtag != 0 && errtag != 2) {
                ERROR("read file failed %d.", errtag);
            }
            fclose(stream);
            stream = NULL;
            if (cfgopr->output.filenum == totalfiles) {
                GetCurrentTime(roundend);
                cfgopr->output.mduringtime = GetTimeDif((char*)cfgopr->output.roundbegin, roundend);
            }
        }
    } else {
        NotifyStopApplication();
    }
    return readsize;
}

void initsent(unsigned int *crcTable, char *msgbuf) {
    struct proto *header = (struct proto*)msgbuf;
    header->id = MULTI_TAG;
    memset(header->reserved, 0, sizeof(header->reserved));
    InitializeCrc(crcTable);
}

void fillsendbuf(size_t rawdatalen, unsigned int *crcTable, const struct inifileopr* cfgopr, char* msgbuf) {
    unsigned int crc = 0;
    const uint16_t packetlen = cfgopr->input.mpsize;
    struct proto *header = (struct proto*)msgbuf;
    header->round = cfgopr->output.curmultround;
    header->fileno = cfgopr->output.filenum;
    if (rawdatalen == packetlen) {
        header->len = 0;
    } else {
        header->len = rawdatalen;
    }
    header->packetno = cfgopr->output.smpnum;
    crc = CalculateCRC((unsigned char*)msgbuf, PACKET_HEADER_LEN + rawdatalen, crcTable);
    header->fileno = htons(header->fileno);
    header->packetno = htonl(header->packetno);
    header->len = htons(header->len);
    crc = htonl(crc);
    memcpy(msgbuf + PACKET_HEADER_LEN + packetlen, (char*)&crc, CRC_SIZE);
}

int initcfgopr(struct inifileopr **cfgopr) {
    int index = 0;
    if ((*cfgopr = malloc(sizeof(struct inifileopr))) == NULL) {
        return -1;
    }
    (*cfgopr)->line = NULL;
    if (((*cfgopr)->linelen = malloc(sizeof(ssize_t) * MAX_PARAM)) == NULL) {
        return -1;
    }
    if (((*cfgopr)->inipath = malloc(1024)) == NULL) {
        return -1;
    }
    if (((*cfgopr)->filebuf = malloc(sizeof(char*) * MAX_PARAM)) == NULL) {
        return -1;
    }
    for (index = 0; index < MAX_PARAM; index++) {
        if (((*cfgopr)->filebuf[index] = malloc(1024)) == NULL) {
            return -1;
        }
    }
    memset(&(*cfgopr)->input, 0, sizeof((*cfgopr)->input));
    memset(&(*cfgopr)->output, 0, sizeof((*cfgopr)->output));
    (*cfgopr)->output.curmultround = 1;
    memset(&(*cfgopr)->calculate, 0, sizeof((*cfgopr)->calculate));
    for (index = 0; index < MAX_PARAM; index++)
        memset((*cfgopr)->filebuf[index], 0, 1024);
    return 0;
}

void destroycfgopr(struct inifileopr *cfgopr) {
    int index = 0;
    if (cfgopr == NULL)
        return;
    free(cfgopr->linelen);
    free(cfgopr->inipath);
    if (cfgopr->filebuf == NULL)
        return;
    for (index = 0; index < MAX_PARAM; index++) {
        free(cfgopr->filebuf[index]);
    }
    free(cfgopr->filebuf);
    free(cfgopr);
}

void SendFilePackets(char* inifile) {
    size_t readsize;
    size_t sendsize;
    struct timeval sleep = {0,0};
    struct timespec nsleep;
    uint16_t rawdatalen;
    uint64_t mbandwidth;
    unsigned int iTable[256];
    timer_t timerid = NULL;
    char current[20] = "0";
    int udpfd = -1;
    struct sockaddr_in destaddr;
    struct inifileopr *cfgopr = NULL;
    static char msgbuf[MPSIZE_LIMIT];

    memset(iTable, 0, sizeof(iTable));
    initsent(iTable, msgbuf);
    if (initcfgopr(&cfgopr) < 0) {
        ERROR("init cfg opr failed.");
        destroycfgopr(cfgopr);
        return;
    }
    memcpy(cfgopr->inipath, inifile, 1024);
    if ((cfgopr->inistream = InitConfigure(cfgopr->inipath, cfgopr->line)) == NULL) {
        destroycfgopr(cfgopr);
        return;
    }
    if (GetInputParam(cfgopr) < 0) {
        FinConfigure(cfgopr->line, cfgopr->inistream);
        destroycfgopr(cfgopr);
        return;
    }
    rawdatalen = cfgopr->input.mpsize;
    mbandwidth = cfgopr->input.mbandwidth;
    GetCurrentTime(current);
    if ((udpfd = InitialMulticastSvr((char*)cfgopr->input.multip, cfgopr->input.multport, cfgopr->input.udpttl, &destaddr)) < 0
        || GetTimeDif(current, (char*)cfgopr->input.endtime) < 0) {
        if (GetTimeDif(current, (char*)cfgopr->input.endtime) < 0)
            ERROR("endtime is early than current, current %s end %s.", current, cfgopr->input.endtime);
        FinConfigure(cfgopr->line, cfgopr->inistream);
        destroycfgopr(cfgopr);
        return;
    }
    if ((timerid = SetLoopTimer(TimerHandle, (void*)cfgopr)) == NULL) {
        FinConfigure(cfgopr->line, cfgopr->inistream);
        destroycfgopr(cfgopr);
        CloseMulticastSvr(udpfd);
        return;
    }

    while (0 == IsAppToBeStopped()) {
        if (cfgopr->input.pausecmd != 0
            || GetTimeDif((char*)cfgopr->input.starttime, (char*)cfgopr->calculate.current) < 0)
            continue;

        readsize = readfile(cfgopr, msgbuf);
        if (0 == readsize) {
            continue;
        } else {
            fillsendbuf(readsize, iTable, cfgopr, msgbuf);
            sendsize = SendMsg(msgbuf, PACKET_HEADER_LEN + rawdatalen + CRC_SIZE, udpfd, &destaddr);
            if (-1 != sendsize) {
                cfgopr->output.curbandwidth += sendsize;
                cfgopr->calculate.sfilesize += sendsize;
                cfgopr->calculate.stotalpackets++;
                sleep.tv_usec = LinerateInterval(sendsize, mbandwidth);
                if (timerisset(&sleep)) {
                    TIMEVAL_TO_TIMESPEC(&sleep, &nsleep);
                    nanosleep(&nsleep, NULL);
                }
            }
        }
    }

    FinConfigure(cfgopr->line, cfgopr->inistream);
    destroycfgopr(cfgopr);
    CloseMulticastSvr(udpfd);
    DeleteLoopTimer(timerid);
}

#if 0
void sleeptest() {
    struct timeval sleep = {0,0};
    struct timespec nsleep;
    if (timerisset(&sleep)) {
        TIMEVAL_TO_TIMESPEC(&sleep, &nsleep);
        nanosleep(&nsleep, NULL);
    }
}
#endif

