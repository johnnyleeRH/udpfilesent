#ifndef UDPFILESENT_MULTICASTSVR_H
#define UDPFILESENT_MULTICASTSVR_H

/*
 * initial multicast svr for udp sent
 * @addr: input, multicast ip
 * @port: input, multicast port
 * @ttl:  input, multicast ttl len
 * @return: 0 success, -1 failed.
 * */
int InitialMulticastSvr(const char* addr, const unsigned short port, const unsigned char ttl);

/*
 * send multicast udp msg
 * @msg: input, udp msg
 * @len: input, msg len
 * */
ssize_t SendMsg(const char *msg, const int len);

/*
 * destory the udp resource
 * */
void CloseMulticastSvr();

#endif
