/*implementation of crc32*/

#include <string.h>

#include "crc.h"
/*
 * crc lookup table array
 * */
static unsigned int iTable[256];
/*
	Reflection is a requirement for the official CRC-32 standard.
	You can create CRCs without it, but they won't conform to the standard.
*/
unsigned int reflect(unsigned int iReflect, const char cChar) {
    unsigned int iValue = 0;
    int iPos = 0;

    // Swap bit 0 for bit 7, bit 1 For bit 6, etc....
    for(iPos = 1; iPos < (cChar + 1); iPos++) {
        if(iReflect & 1) {
            iValue |= (1 << (cChar - iPos));
        }
        iReflect >>= 1;
    }

    return iValue;
}

void InitializeCrc(void) {
    //0x04C11DB7 is the official polynomial used by PKZip, WinZip and Ethernet.
    unsigned int iPolynomial = 0x04C11DB7;
    int iCodes = 0;
    int iPos = 0;

    memset(&iTable, 0, sizeof(iTable));
    // 256 values representing ASCII character codes.
    for(iCodes = 0; iCodes <= 0xFF; iCodes++) {
        iTable[iCodes] = reflect(iCodes, 8) << 24;

        for(iPos = 0; iPos < 8; iPos++) {
            iTable[iCodes] = (iTable[iCodes] << 1) ^ ((iTable[iCodes] & (1 << 31)) ? iPolynomial : 0);
        }
        iTable[iCodes] = reflect(iTable[iCodes], 32);
    }
}

/*
 * Calculates the CRC32 by looping through each of the bytes in sData.
*/

void partialCRC(unsigned int *iCRC, const unsigned char *sData, size_t iDataLength) {
    while(iDataLength--) {
        *iCRC = (*iCRC >> 8) ^ iTable[(*iCRC & 0xFF) ^ *sData++];
    }
}

unsigned int CalculateCRC(const unsigned char *sData, size_t iDataLength) {
    unsigned int iCRC = 0xffffffff;
    partialCRC(&iCRC, sData, iDataLength);
    return (iCRC ^ 0xffffffff);
}