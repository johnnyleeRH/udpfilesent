static int g_isAppToBeStoppedFlag = 0;

void NotifyStopApplication() {
    __sync_add_and_fetch( &g_isAppToBeStoppedFlag, 1 );
}

int IsAppToBeStopped() {
    int flag = __sync_fetch_and_add( &g_isAppToBeStoppedFlag , 0 );
    if ( flag > 0 )
        return 1;
    else
        return 0;
}