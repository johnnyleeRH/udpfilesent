#include <arpa/inet.h>
#include <errno.h>
#include <signal.h>
#include <sys/time.h>
#include <time.h>
#include <stdio.h>
#include <string.h>

#include "crc.h"
#include "filesent.h"
#include "iniopr.h"
#include "paramdef.h"
#include "protocol.h"
#include "log.h"
#include "multicastsvr.h"
#include "timeopr.h"
#include "notify.h"

static int sendpaused = 0;
static char msgbuf[MPSIZE_LIMIT];
static char roundend[20] = "0";
static char roundbegin[20] = "0";
static FILE* stream = NULL;
static int curfileno = 0;
static int curatime = 1;
static int curmulnum = 1;
static int packetinfile = 0;
static uint64_t bandwidth = 0;
static char smpath[1024] = "0";
struct calcparam   calculate;
/*
 * Calculate line rate interval in microseconds for the given
 * pkt_len (bytes) and linerate (bit)
 *
 * to send packets at line rate with assumption of link speed at X:
 * interval = ((packet length * bits per byte) / (X)) * 1000000
 * ex:
 * +---------------------------------------------------+
 * |            | 10Mbps      | 100Mbps    | 1000Mbps  |
 * +---------------------------------------------------+
 * |   14 bytes | 11 usecs.   | 1 usecs.   | 0 usecs.  |
 * | 1514 bytes | 1155 usecs. | 116 usecs. | 12 usecs. |
 * +---------------------------------------------------+
 */

int LinerateInterval(const int pktlen, const int linerate) {
    return ROUND(((float)pktlen * 8) / linerate * 1000000);
}

void SetPauseState(int paused) {
    sendpaused = paused;
}

void TimerHandle(sigval_t sigval) {
    char tm[20] = "0";
    GetCurrentTime((char*)calculate.current);
    SetCurrentMulticastRound(curmulnum);
    SetCurrentFileNo(curfileno);
    SetCurrentPackNo(packetinfile);
    SetCurrentBandWidth(bandwidth * 8);
    UpdateParam(&calculate);
    GetEndTime(tm);
    if (GetTimeDif((char*)calculate.current, tm) < 0) {
        INFO("endtime is early than current.");
        NotifyStopApplication();
        return;
    }
    GetStartTime(tm);
    if (GetPausedCmd() != 0
        || GetTimeDif((char*)tm, (char*)calculate.current) < 0)
        sendpaused = 1;
    else
        sendpaused = 0;
    bandwidth = 0;
}

void preparefile() {
    static char fileid[1024];
    const uint8_t afiles = GetPriorityFiles();
    const uint16_t sfiles = GetTotalFiles();
    const uint16_t packetlen = GetPacketLen();
    const uint8_t atimes = GetPriorityCounts();
    const int originfile = curfileno;
    int errtag = 0;

    if (stream != NULL)
        return;
    while (curmulnum <= MULTNUM_LIMIT) {
        /*
         * just exception handing
         * */
        if (afiles >= sfiles) {
            if (curfileno < sfiles) {
                curfileno++;
            } else {
                if (atimes == 0 || atimes == 1) {
                    if (curfileno == sfiles) {
                        curfileno = 1;
                        curmulnum++;
                        if (curmulnum > MULTNUM_LIMIT) {
                            ERROR("multicast times over %d.", MULTNUM_LIMIT);
                            return;
                        }
                    }
                } else {
                    if (curfileno == sfiles) {
                        curfileno = 1;
                        if (curatime == atimes) {
                            curatime = 1;
                            curmulnum++;
                            if (curmulnum > MULTNUM_LIMIT) {
                                ERROR("multicast times over %d.", MULTNUM_LIMIT);
                                return;
                            }
                        } else {
                            curatime++;
                        }
                    }
                }
            }
        } else {
            if (curfileno < afiles) {
                curfileno++;
            } else if (curfileno == afiles) {
                if (0 == atimes || 1 == atimes) {
                    curfileno++;
                } else {
                    if (curatime < atimes) {
                        curatime++;
                        curfileno = 1;
                    } else {
                        curatime = 1;
                        curfileno++;
                    }
                }
            } else {
                if (curfileno < sfiles) {
                    curfileno++;
                } else {
                    curfileno = 1;
                    curmulnum++;
                    if (curmulnum > MULTNUM_LIMIT) {
                        ERROR("multicast times over %d.", MULTNUM_LIMIT);
                        return;
                    }
                }
            }
        }
        memset(fileid, 0, sizeof(fileid));
        snprintf(fileid, sizeof(fileid), "%s%d", smpath, curfileno);
        if (curfileno == 1) {
            GetCurrentTime(roundbegin);
            SetRoundBeginTime(roundbegin);
        }
        stream = fopen(fileid, "r");
        if (stream == NULL) {
            errtag = errno;
            if (2 != errtag)
                ERROR("file %s open failed %d.", fileid, errtag);
            if (curfileno == sfiles) {
                GetCurrentTime(roundend);
                SetDuringTime(GetTimeDif(roundbegin, roundend));
            }
            /*means that circle search but no file can be opened, shall stop multicast.*/
            if (originfile == curfileno) {
                INFO("no file need to send.");
                NotifyStopApplication();
                return;
            }
            continue;
        }
        fseek(stream, 0, SEEK_END);
        calculate.filesize = ftell(stream);
        calculate.fileptotal = (calculate.filesize + packetlen - 1) / packetlen;
        rewind(stream);
        packetinfile = 0;
        return;
    }
}

int readfile() {
    size_t readsize = 0;
    const uint16_t packetlen = GetPacketLen();
    const uint16_t totalfiles = GetTotalFiles();
    int errtag = 0;
    preparefile();
    if (stream != NULL) {
        readsize = fread(msgbuf + PACKET_HEADER_LEN, 1, packetlen, stream);
        packetinfile++;
        if (readsize != packetlen) {
            errtag = errno;
            if (errtag != 0) {
                ERROR("read file failed %d.", errtag);
            }
            fclose(stream);
            stream = NULL;
            if (curfileno == totalfiles) {
                GetCurrentTime(roundend);
                SetDuringTime(GetTimeDif(roundbegin, roundend));
            }
        }
    } else {
        NotifyStopApplication();
    }
    return readsize;
}

void initsent() {
    struct proto *header = (struct proto*)msgbuf;
    header->id = MULTI_TAG;
    memset(header->reserved, 0, sizeof(header->reserved));
    InitializeCrc();
    GetFileFolder(smpath);
    memset((char*)&calculate, 0, sizeof(calculate));
}

void fillsendbuf(size_t rawdatalen) {
    unsigned int crc = 0;
    const uint16_t packetlen = GetPacketLen();
    struct proto *header = (struct proto*)msgbuf;
    header->round = curmulnum;
    header->fileno = curfileno;
    if (rawdatalen == packetlen) {
        header->len = 0;
    } else {
        header->len = rawdatalen;
    }
    header->packetno = packetinfile;
    crc = CalculateCRC((unsigned char*)msgbuf, PACKET_HEADER_LEN + rawdatalen);
    header->fileno = htons(header->fileno);
    header->packetno = htonl(header->packetno);
    header->len = htons(header->len);
    crc = htonl(crc);
    memcpy(msgbuf + PACKET_HEADER_LEN + packetlen, (char*)&crc, CRC_SIZE);
}

void SendFilePackets() {
    size_t readsize;
    size_t sendsize;
    struct timeval sleep = {0,0};
    struct timespec nsleep;
    const uint16_t rawdatalen = GetPacketLen();
    const uint64_t mbandwidth = GetLimitBandWidth();
    initsent();

    while (0 == IsAppToBeStopped()) {
        if (sendpaused != 0)
            continue;
        readsize = readfile();
        if (0 == readsize) {
            continue;
        } else {
            fillsendbuf(readsize);
            sendsize = SendMsg(msgbuf, PACKET_HEADER_LEN + rawdatalen + CRC_SIZE);
            if (-1 != sendsize) {
                bandwidth += sendsize;
                calculate.sfilesize += sendsize;
                calculate.stotalpackets++;
                sleep.tv_usec = LinerateInterval(sendsize, mbandwidth);
                if (timerisset(&sleep)) {
                    TIMEVAL_TO_TIMESPEC(&sleep, &nsleep);
                    nanosleep(&nsleep, NULL);
                }
            }
        }
    }
}

#if 0
void sleeptest() {
    struct timeval sleep = {0,0};
    struct timespec nsleep;
    if (timerisset(&sleep)) {
        TIMEVAL_TO_TIMESPEC(&sleep, &nsleep);
        nanosleep(&nsleep, NULL);
    }
}
#endif

