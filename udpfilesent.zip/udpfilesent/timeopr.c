#include <errno.h>
#include <signal.h>
#include <string.h>
#include <pthread.h>
/*#include <stdio.h>*/

#include "log.h"
#include "timeopr.h"

/*void testfunc(sigval_t sigval) {
    int* p = (int*)sigval.sival_ptr;
    printf("haha\n");
}*/

void DeleteLoopTimer(timer_t timerid) {
    if (timerid != NULL)
        timer_delete(timerid);
}

timer_t SetLoopTimer(void* func, void* param) {
    struct sigevent evp;
    struct itimerspec tmspec;
    const time_t kdelay = 1;
    timer_t timerid = NULL;

    memset(&evp, 0, sizeof(evp));
    evp.sigev_value.sival_ptr = param;
    evp.sigev_notify = SIGEV_THREAD;
    evp.sigev_notify_function = func;
    if (timer_create(CLOCK_REALTIME, &evp, &timerid) < 0) {
        ERROR("fail to create login timer %d!\n", errno);
        return NULL;
    }

    memset(&tmspec, 0, sizeof(tmspec));
    tmspec.it_value.tv_sec =  kdelay;
    tmspec.it_value.tv_nsec = 0;
    tmspec.it_interval.tv_sec = kdelay;
    tmspec.it_interval.tv_nsec = 0;
    if (timer_settime(timerid, 0, &tmspec, 0) < 0) {
        ERROR("fail to set login timer failed %d!\n", errno);
        return NULL;
    }
    return timerid;
}

void GetCurrentTime(char* tm) {
    time_t now;
    struct tm *ts;
    time(&now);
    ts = localtime(&now);
    strftime(tm, 20, "%Y-%m-%d %H:%M:%S", ts);
}

time_t GetSecondsFromTime(const char* tm) {
    struct tm timeofday;
    memset(&timeofday, 0, sizeof(timeofday));
    timeofday.tm_year = atoi(tm) - 1900;
    timeofday.tm_mon = atoi(tm + 5) - 1;
    timeofday.tm_mday = atoi(tm + 8);
    timeofday.tm_hour = atoi(tm + 11);
    timeofday.tm_min = atoi(tm + 14);
    timeofday.tm_sec = atoi(tm + 17);
    return mktime(&timeofday);
}

time_t GetTimeDif(const char* begin, const char* end) {
    time_t beginsec = GetSecondsFromTime(begin);
    time_t endsec = GetSecondsFromTime(end);
    return endsec - beginsec;
}

#if 0
int main() {
    char tm[20] = "2017-04-13 19:30:15";
    char tmend[20];
    GetCurrentTime(tmend);
    printf("%d.\n", GetTimeDif(tmend, tm));
}
#endif

