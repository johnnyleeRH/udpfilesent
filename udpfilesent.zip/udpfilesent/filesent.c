#include <arpa/inet.h>
#include <errno.h>
#include <signal.h>
#include <sys/time.h>
#include <time.h>
#include <stdio.h>
#include <string.h>

#include "crc.h"
#include "filesent.h"
#include "iniopr.h"
#include "paramdef.h"
#include "protocol.h"
#include "log.h"
#include "multicastsvr.h"
#include "timeopr.h"

extern int IsAppToBeStopped();
extern void NotifyStopApplication();
extern int g_paused;

static char msgbuf[MPSIZE_LIMIT];
static char roundend[20] = "0";
static FILE* stream = NULL;
static int curfileno = 0;
static int curatime = 1;
static int curmulnum = 1;
static int packetinfile = 0;
static uint64_t bandwidth = 0;
/*
 * Calculate line rate interval in microseconds for the given
 * pkt_len (bytes) and linerate (bit)
 *
 * to send packets at line rate with assumption of link speed at X:
 * interval = ((packet length * bits per byte) / (X)) * 1000000
 * ex:
 * +---------------------------------------------------+
 * |            | 10Mbps      | 100Mbps    | 1000Mbps  |
 * +---------------------------------------------------+
 * |   14 bytes | 11 usecs.   | 1 usecs.   | 0 usecs.  |
 * | 1514 bytes | 1155 usecs. | 116 usecs. | 12 usecs. |
 * +---------------------------------------------------+
 */

int LinerateInterval(const int pktlen, const int linerate) {
    return ROUND(((float)pktlen * 8) / linerate * 1000000);
}

void timerhandle(sigval_t sigval) {
    GetCurrentTime((char*)calculate.current);
    output.curmultround = curmulnum;
    output.filenum = curfileno;
    output.smpnum = packetinfile;
    output.rbandwidth = bandwidth * 8;
    UpdateParam();
    if (input.pausecmd != 0
        || GetTimeDif((char*)input.starttime, (char*)calculate.current) < 0
        || GetTimeDif((char*)calculate.current, (char*)input.endtime) < 0)
        g_paused = 1;
    else
        g_paused = 0;
    bandwidth = 0;
}

void preparefile() {
    static char fileid[1024];
    int errtag = 0;
    if (stream != NULL)
        return;
    while (curmulnum <= input.multnum) {
        /*
         * just exception handing
         * */
        if (input.afiles >= input.sfiles) {
            if (curfileno < input.sfiles) {
                curfileno++;
            } else {
                if (input.atimes == 0 || input.atimes == 1) {
                    if (curfileno == input.sfiles) {
                        curfileno = 1;
                        curmulnum++;
                        if (curmulnum > input.multnum)
                            return;
                    }
                } else {
                    if (curfileno == input.sfiles) {
                        curfileno = 1;
                        if (curatime == input.atimes) {
                            curatime = 1;
                            curmulnum++;
                            if (curmulnum > input.multnum)
                                return;
                        } else {
                            curatime++;
                        }
                    }
                }
            }
        } else {
            if (curfileno < input.afiles) {
                curfileno++;
            } else if (curfileno == input.afiles) {
                if (0 == input.atimes || 1 == input.atimes) {
                    curfileno++;
                } else {
                    if (curatime < input.atimes) {
                        curatime++;
                        curfileno = 1;
                    } else {
                        curatime = 1;
                        curfileno++;
                    }
                }
            } else {
                if (curfileno < input.sfiles) {
                    curfileno++;
                } else {
                    curfileno = 1;
                    curmulnum++;
                    if (curmulnum > input.multnum)
                        return;
                }
            }
        }
        memset(fileid, 0, sizeof(fileid));
        snprintf(fileid, sizeof(fileid), "%s%d", input.smpath, curfileno);
        if (curfileno == 1) {
            GetCurrentTime((char*)output.roundbegin);
        }
        stream = fopen(fileid, "r");
        if (stream == NULL) {
            errtag = errno;
            if (2 != errtag)
                ERROR("file %s open failed %d.", fileid, errtag);
            if (curfileno == input.sfiles) {
                GetCurrentTime(roundend);
                output.mduringtime = GetTimeDif((char*)output.roundbegin, roundend);
            }
            continue;
        }
        fseek(stream, 0, SEEK_END);
        calculate.filesize = ftell(stream);
        calculate.fileptotal = (calculate.filesize + input.mpsize - 1) / input.mpsize;
        rewind(stream);
        packetinfile = 0;
        return;
    }
}

int readfile() {
    size_t readsize = 0;
    int errtag = 0;
    preparefile();
    if (stream != NULL) {
        readsize = fread(msgbuf + PACKET_HEADER_LEN, 1, input.mpsize, stream);
        packetinfile++;
        if (readsize != input.mpsize) {
            errtag = errno;
            if (errtag != 0) {
                ERROR("read file failed %d.", errtag);
            }
            fclose(stream);
            stream = NULL;
            if (curfileno == input.sfiles) {
                GetCurrentTime(roundend);
                output.mduringtime = GetTimeDif((char*)output.roundbegin, roundend);
            }
        }
    } else {
        NotifyStopApplication();
    }
    return readsize;
}

void initsent() {
    struct proto *header = (struct proto*)msgbuf;
    header->id = MULTI_TAG;
    memset(header->reserved, 0, sizeof(header->reserved));
    InitializeCrc();
}

void fillsendbuf(size_t rawdatalen) {
    unsigned int crc = 0;
    struct proto *header = (struct proto*)msgbuf;
    header->round = curmulnum;
    header->fileno = curfileno;
    if (rawdatalen == input.mpsize) {
        header->len = 0;
    } else {
        header->len = rawdatalen;
    }
    header->packetno = packetinfile;
    crc = CalculateCRC((unsigned char*)msgbuf, PACKET_HEADER_LEN + rawdatalen);
    header->fileno = htons(header->fileno);
    header->packetno = htonl(header->packetno);
    header->len = htons(header->len);
    crc = htonl(crc);
    memcpy(msgbuf + PACKET_HEADER_LEN + input.mpsize, (char*)&crc, CRC_SIZE);
}

void SendFilePackets() {
    size_t readsize;
    size_t sendsize;
    struct timeval sleep = {0,0};
    struct timespec nsleep;
    initsent();

    while (!IsAppToBeStopped()) {
        if (g_paused != 0)
            continue;
        readsize = readfile();
        if (0 == readsize) {
            continue;
        } else {
            fillsendbuf(readsize);
            sendsize = SendMsg(msgbuf, PACKET_HEADER_LEN + input.mpsize + CRC_SIZE);
            bandwidth += sendsize;
            calculate.sfilesize += sendsize;
            calculate.stotalpackets++;
            sleep.tv_usec = LinerateInterval(sendsize, input.mbandwidth);
            if (timerisset(&sleep)) {
                TIMEVAL_TO_TIMESPEC(&sleep, &nsleep);
                nanosleep(&nsleep, NULL);
            }
        }
    }
}

#if 0
void sleeptest() {
    struct timeval sleep = {0,0};
    struct timespec nsleep;
    if (timerisset(&sleep)) {
        TIMEVAL_TO_TIMESPEC(&sleep, &nsleep);
        nanosleep(&nsleep, NULL);
    }
}
#endif

