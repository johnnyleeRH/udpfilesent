#ifndef UDPFILESENT_INIOPR_H
#define UDPFILESENT_INIOPR_H

#include <stdint.h>
extern struct inputparam  input;
extern struct outputparam output;
extern struct calcparam   calculate;
/*
 * @file: input, ini configure file
 * @return 0 success -1 failed
 * init configure file when process begin
 * */
int InitConfigure(char *file);
/*
 * when process end, shall do this first
 * */
void FinConfigure();
/*
 * @return 0 success -1 failed
 * get init input param from ini file.
 * */
int GetInputParam();
/*
 * @return 0 success -1 failed
 * update the output/calculat param to ini file,
 * and get the new pausecmd and endtime param.
 * */
int UpdateParam();


/*output interface*/
/*
 * return filenum
 * */
uint16_t GetCurrentFileNo();
/*
 * return current udp number
 * */
uint64_t GetCurrentPackNo();
/*
 * return rbandwidth
 * */
uint64_t GetCurrentBandWidth();
/*
 * return mduringtime
 * */
uint64_t GetLastTimeCost();
/*
 * return current multicast round
 * */
uint8_t GetCurrentMulticastRound();
/*
 * @begin: output, the formatted multicast round begin time, the begin buf shall more than 20 bytes.
 * */
void GetRoundBeginTime(char* begin);
#endif
