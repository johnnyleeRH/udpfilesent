#ifndef UDPFILESENT_TIMEOPR_H
#define UDPFILESENT_TIMEOPR_H

#include <stdlib.h>
/*
 * delte timer
 * */
void DeleteLoopTimer();

/*
 * set loop timer
 * @func: input, func to handle when timer expire
 * @return: 0 success, -1 failed
 * */
int SetLoopTimer(void* func);

/*
 * @tm: output, get the formatted time, tm shall be more than 20 bytes
 * */
void GetCurrentTime(char* tm);

/*
 * @tm: input, the formatted time buf
 * @return the seconds from the formatted time
 * */
time_t GetSecondsFromTime(const char* tm);

/*
 * @begin: input, the formatted begin time
 * @end: input, the formatted end time
 * @return the diff seconds of the begin and end time
 * */
time_t GetTimeDif(const char* begin, const char* end);

#endif
