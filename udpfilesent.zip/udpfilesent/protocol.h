#ifndef UDPFILESENT_PROTOCOL_H
#define UDPFILESENT_PROTOCOL_H

#include <stdint.h>

#pragma pack(push,1)

#define MULTI_TAG 0x50
#define CRC_SIZE  4
#define PACKET_HEADER_LEN (sizeof(struct proto))

struct proto {
	uint8_t id;
	uint16_t round;
	uint16_t fileno;
	uint32_t  packetno;
	char reserved[1];
	uint16_t len;
};

#pragma pack(pop)
#endif
