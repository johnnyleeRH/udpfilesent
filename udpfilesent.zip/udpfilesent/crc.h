#ifndef UDPFILESENT_CRC_H
#define UDPFILESENT_CRC_H

void InitializeCrc();
/*
 * Returns the calculated CRC32 for the given string.
*/
unsigned int CalculateCRC(const unsigned char *sData, size_t iDataLength);

#endif
